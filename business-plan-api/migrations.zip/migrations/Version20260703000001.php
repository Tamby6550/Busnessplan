<?php

declare(strict_types=1);

namespace App\Migration;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Le montant des charges d'exploitation devient mensuel (variation possible selon le mois),
 * même principe que Version20260702000001.php (produits) et Version20260703000000.php (matières).
 *
 * La colonne existante `monthly_amount` n'est PAS touchée : elle continue de représenter le
 * montant de Janvier (mois 1) — aucune donnée existante n'est perdue ou modifiée.
 * La colonne `seasonality` n'est pas touchée non plus (déjà un tableau JSON, aucune migration
 * nécessaire) — elle est juste relabellisée "Quantité" côté interface, sans changement de données.
 *
 * 11 nouvelles colonnes sont ajoutées pour les mois 2 à 12 (Février à Décembre) :
 * monthly_amount_m2, monthly_amount_m3, ..., monthly_amount_m12 — BIGINT NOT NULL DEFAULT 0.
 * Elles démarrent à 0 (et non recopiées depuis Janvier), à saisir par l'utilisateur.
 *
 * Idempotente (vérifie chaque colonne via INFORMATION_SCHEMA avant de l'ajouter).
 */
final class Version20260703000001 extends AbstractMigration
{
    public function getDescription(): string
    {
        return "expenses : ajout de monthly_amount_m2..monthly_amount_m12 (montant mensuel, monthly_amount = montant Janvier inchangé, seasonality inchangée)";
    }

    public function up(Schema $schema): void
    {
        $db = $this->connection->getDatabase();
        $previous = 'monthly_amount';

        for ($m = 2; $m <= 12; $m++) {
            $col = "monthly_amount_m{$m}";

            $exists = (int) $this->connection->fetchOne(
                'SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = \'expenses\' AND COLUMN_NAME = ?',
                [$db, $col]
            );

            if ($exists === 0) {
                $this->addSql("ALTER TABLE expenses ADD COLUMN {$col} BIGINT NOT NULL DEFAULT 0 AFTER {$previous}");
            }

            $previous = $col;
        }
    }

    public function down(Schema $schema): void
    {
        for ($m = 2; $m <= 12; $m++) {
            $this->addSql("ALTER TABLE expenses DROP COLUMN monthly_amount_m{$m}");
        }
    }
}
